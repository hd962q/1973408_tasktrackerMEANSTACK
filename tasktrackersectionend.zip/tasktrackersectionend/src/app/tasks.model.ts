export class task{
    constructor(
        public Id:number,
        public name:string,
        public tasks:string,
        public date:Date){}
}